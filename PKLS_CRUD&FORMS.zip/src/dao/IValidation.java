package dao;

public interface IValidation {
	
	public boolean isEMailExist(String email);
		

}
