package Driver;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DriverBooking
 */
@WebServlet("/DriverBooking")
public class DriverBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DriverBooking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession();
		out.print("<title>Booking");
		out.print("</title>");
		out.println("<link href=w3.css rel=stylesheet type=text/css>"); 
		out.println("<script type='text/javascript'>");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/functions.js");
		out.println("</script>");
		
		RequestDispatcher rd = request
				.getRequestDispatcher("/Header.jsp");
		rd.include(request, response);
		
		out.print("<body>");
		out.print("<div class=\"form-style-5\" align='center' style='background:url(images/img01.gif) repeat'>");
		out.println("<br/><br/><br/><br/><br/>");
		
		out.print("<h1>Driver Booking</h1>");
		out.println("<br/><br/><br/>");
		
		out.println("<div class=\"form\">");
		
		out.print("<label><i class=\"fa fa-male\"></i> Customer Name</label>");
		out.print("<input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Customer Name\">");
		out.print("<br/>");
		
		out.print("<label><i class=\"fa fa-male\"></i> Driver Name</label>");
		out.print("<input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Driver Name\">");
		out.print("<br/>");
		
		out.print("<label><i class=\"fa fa-calendar-o\"></i> No of Days</label>");
		out.print("<select id=\"type\" name=\"type\" onchange=\"javascript: dynamicdropdown(this.options[this.selectedIndex].value);\">");
		out.print("<option value=\"Below 7 Days\">Below 7 Days</option>");
		out.print("<option value=\"7 Days Trip\">7 Days Trip</option>");
		out.print("<option value=\"Above 7 Days\">Above 7 Days</option>");
		out.print("</select>");
		out.print("<br/>");
		
		out.print("<label><i class=\"fa fa-calendar-o\"></i> Price per day</label>");
		out.print("<script type=\"text/javascript\" language=\"JavaScript\"> document.write('<select name=\"status\" id=\"status\"><option value=\"\">Select </option></select>')\r\n" + "");
		out.print("</script>");
		out.print("<noscript><select id=\"status\" name=\"status\">");
		out.print("<option value=\"65 USD\">65 USD</option>");
		out.print("<option value=\"2\">2</option>");
		out.print("</select></noscript>");
		out.print("<br/>");
		
		out.print("<button onclick=\"calc()\"></button>");
		
		
			
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
