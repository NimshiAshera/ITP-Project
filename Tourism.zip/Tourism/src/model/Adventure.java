package model;

import java.sql.ResultSet;

import com.mysql.cj.protocol.Resultset;

import dao.DBConnection;

public class Adventure {
	private String part;
	private String name;
	private String company_id;
	private String dbimagelocation;
	private String contact_no;
	private String address;
	private String Details;
	private String Price;
	private String avb;
	private String username;
	private String password;
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}
	public String getDbimagelocation() {
		return dbimagelocation;
	}
	public void setDbimagelocation(String dbimagelocation) {
		this.dbimagelocation = dbimagelocation;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		Details = details;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getAvb() {
		return avb;
	}
	public void setAvb(String avb) {
		this.avb = avb;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@SuppressWarnings("null")
	public boolean isEMailExist(String email) {
		
		try{
			Resultset mail = (Resultset) DBConnection.DBquery("select * from adcom");
			
			//process results
			
			while(((ResultSet) mail).next()){
				if(email.equals(((ResultSet) mail).getString("email")))
					return true;
		}
			
		return false;
		
	}catch(Exception ex){
		ex.printStackTrace();
		return (Boolean) null;
	}
		
	}
	public static Adventure getAdventure(String name) {
		// TODO Auto-generated method stub
		return null;
	}
		
	
	
	
}
