/**
 * 
 */

function dynamicdropdown(listindex)
    {
        switch (listindex)
        {
        case "Below 7 Days" :
            document.getElementById("status").options[0]=new Option("Select ","");
            document.getElementById("status").options[1]=new Option("65 USD","65 USD");
            break;
        case "7 Days Trip" :
            document.getElementById("status").options[0]=new Option("Select ","");
            document.getElementById("status").options[1]=new Option("55 USD","55 USD");            
            break;
        case "Above 7 Days" :
            document.getElementById("status").options[0]=new Option("Select ","");
            document.getElementById("status").options[1]=new Option("50 USD ","50 USD");
            break;
        }
        return true;
    }

function calc(){
	var field1=document.getElementById("type").value;
	var field2= document.getElementById("status").value;
	
	
	var result=parseFloat(field1)* parseFloat(field2);
	
	if(!isNaN(result)){
		document.getElementById("answer").innerHTML="Total : "+result;
	}
	
	
}